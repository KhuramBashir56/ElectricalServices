<x-layouts.web :title="__('Home Page')">
    <section class="w-full bg-no-repeat bg-cover p-3" style="background-image: url({{ asset('web/background-images/main-bg.webp') }})">
        <div class="lg:container md:p-16 p-3 mx-auto">
            <div class="bg-white max-w-md rounded-lg py-5 px-8 text-blue-900">
                <h1 class="text-4xl font-bold">{{ __('web/home/main.heading') }}</h1>
                <p class="text-lg text-gray-500 my-5">{{ __('web/home/main.description') }}</p>
                <button class="border-2 block mx-auto border-yellow-500 px-8 py-3 font-bold hover:bg-yellow-500 hover:text-white">{{ __('web/menu-bar.contactUs') }}</button>
            </div>
        </div>
    </section>
    <section class="w-full px-3 py-16">
        <div class="2xl:container mx-auto flex flex-col md:flex-row gap-10">
            <div class="md:w-1/2 w-full h-[500px] flex gap-x-5 relative">
                <div class="bg-white place-self-end w-[102px] aspect-square">
                    <span dir="ltr" class="text-6xl block text-blue-900">10<span class="text-yellow-500">+</span></span>
                    <span class="block">{{ __('web/home/about.experience') }}</span>
                </div>
                <div class="w-full h-full bg-cover" style="background-image: url({{ asset('web/background-images/about-bg-2.jpg') }});"></div>
                <div class="w-1/2 border-y-8 ltr:border-r-8 rtl:border-l-8 border-yellow-500 absolute translate-y-[120px] bg-cover" style="height: calc(100% - 240px); background-image:url({{ asset('web/background-images/about-bg-1.webp') }})"></div>
            </div>
            <div class="md:w-1/2">
                <h1 class="text-4xl font-bold text-blue-900">{{ __('web/home/about.heading') }}</h1>
                <p class="text-lg text-gray-500 my-5">{{ __('web/home/about.description') }}</p>
                <div class="w-full flex gap-x-16">
                    <div class="w-1/2">
                        <div class="w-16 mb-5 aspect-square bg-yellow-400 text-blue-900 rounded-full flex justify-center items-center">
                            <svg width="36" height="36" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022l-.074.997zm2.004.45a7.003 7.003 0 0 0-.985-.299l.219-.976c.383.086.76.2 1.126.342l-.36.933zm1.37.71a7.01 7.01 0 0 0-.439-.27l.493-.87a8.025 8.025 0 0 1 .979.654l-.615.789a6.996 6.996 0 0 0-.418-.302zm1.834 1.79a6.99 6.99 0 0 0-.653-.796l.724-.69c.27.285.52.59.747.91l-.818.576zm.744 1.352a7.08 7.08 0 0 0-.214-.468l.893-.45a7.976 7.976 0 0 1 .45 1.088l-.95.313a7.023 7.023 0 0 0-.179-.483zm.53 2.507a6.991 6.991 0 0 0-.1-1.025l.985-.17c.067.386.106.778.116 1.17l-1 .025zm-.131 1.538c.033-.17.06-.339.081-.51l.993.123a7.957 7.957 0 0 1-.23 1.155l-.964-.267c.046-.165.086-.332.12-.501zm-.952 2.379c.184-.29.346-.594.486-.908l.914.405c-.16.36-.345.706-.555 1.038l-.845-.535zm-.964 1.205c.122-.122.239-.248.35-.378l.758.653a8.073 8.073 0 0 1-.401.432l-.707-.707z" />
                                <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0v1z" />
                                <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5z" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-lg font-bold text-blue-900 not-italic">{{ __('web/home/about.serviceTitle') }}</p>
                            <p class="text-gray-500 not-italic">{{ __('web/home/about.serviceDescription') }}</p>
                        </div>
                    </div>
                    <div class="w-1/2">
                        <div class="w-16 mb-5 aspect-square bg-yellow-400 text-blue-900 rounded-full flex justify-center items-center">
                            <svg width="36" height="36" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8Zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022ZM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM6.936 9.28a5.88 5.88 0 0 0-1.23-.247A7.35 7.35 0 0 0 5 9c-4 0-5 3-5 4 0 .667.333 1 1 1h4.216A2.238 2.238 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816ZM4.92 10A5.493 5.493 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0Zm3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-lg font-bold text-blue-900 not-italic">{{ __('web/home/about.teamTitle') }}</p>
                            <p class="text-gray-500 not-italic">{{ __('web/home/about.teamDescription') }}</p>
                        </div>
                    </div>
                </div>
                <button class="border-2 mt-8 block mx-auto border-yellow-500 px-8 py-3 font-bold hover:bg-yellow-500 hover:text-white">{{ __('web/home/about.aboutUs') }}</button>
            </div>
        </div>
    </section>
</x-layouts.web>
3
