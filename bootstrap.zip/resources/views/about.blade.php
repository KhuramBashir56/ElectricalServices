<x-layouts.web :title="__('Home Page')">
   About
</x-layouts.web>