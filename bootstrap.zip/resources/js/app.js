$(function () {
    $('#menuToggle').on('click', function () {
        $('#mainMenu').slideToggle();
    });
    $('#languagesToggle').on('click', function () {
        $('#languageMenu').slideToggle();
    });
});