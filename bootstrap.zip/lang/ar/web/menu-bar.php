<?php
return [
    'home' => 'الصفحة الرئيسية',
    'contactUs' => 'اتصل بنا',
    'gallery' => 'صالة عرض',
    'aboutUs' => 'معلومات عنا',
    'languages' => 'اللغات',
    'menuToggle' => 'القائمة الرئيسية',
];
