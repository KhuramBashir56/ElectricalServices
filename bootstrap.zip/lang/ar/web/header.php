<?php
return [
    'country' => 'العربيه السعوديه',
    'address' => 'مدينة تبوك',
    'contact' => 'اتصل بنا',
    'contact_number' => '+966-123-045-6789',
    'email' => 'أرسل بريدا إلكترونيا',
    'email_address' => 'abccompany@abc.com'
];
