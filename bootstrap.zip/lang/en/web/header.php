<?php
return [
    'country' => 'Saudi Arabia',
    'address' => 'Tabuk City',
    'contact' => 'Contact Us',
    'contact_number' => '+966-123-045-6789',
    'email' => 'Send an Eamil',
    'email_address' => 'abccompany@abc.com'
];
