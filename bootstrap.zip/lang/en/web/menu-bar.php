<?php
return [
    'home' => 'Home',
    'contactUs' => 'Contact Us',
    'gallery' => 'Gallery',
    'aboutUs' => 'About Us',
    'languages' => 'languages',
    'menuToggle' => 'Main Menu',

];
