<?php
return [
    'heading' => 'We are committed to excellence in electrical work',
    'description' => 'Our way of working is what makes us different from others. We are there as electricians for your home, office and your firm. Our priority is your satisfaction and the excellence of our work. Contact us for electrical repair and maintenance.'
];
